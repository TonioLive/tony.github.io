# DUB EDITION WEB

Web estática preparada para GitHub Pages.

## Archivos

- `index.html`: home principal.
- `rutas.html`: sección de rutas.
- `eventos.html`: historia de DUB21 en Circuit Ricardo Tormo junto a Probike Racing.
- `comunidad.html`: acceso al canal de Instagram.
- `unete.html`: formularios para empresas y miembros.
- `style.css`: diseño completo responsive.
- `script.js`: menú móvil, animaciones, pestañas y límite de 2 fotos.

## Subir a GitHub Pages

1. Sube todos los archivos al repositorio.
2. Ve a Settings > Pages.
3. Source: Deploy from a branch.
4. Branch: main.
5. Folder: / root.
6. Guarda y espera a que GitHub publique.

## Formularios

GitHub Pages no procesa formularios ni guarda archivos porque es hosting estático.

Opciones recomendadas:

### Opción rápida: Formspree

1. Crea cuenta en Formspree.
2. Crea un formulario para empresas y otro para miembros.
3. Copia el endpoint.
4. En `unete.html`, cambia `action=""` por tu URL de Formspree.

Ejemplo:

```html
<form class="form-card" action="https://formspree.io/f/xxxxxxx" method="POST">
```

Para el formulario del club con fotos, revisa que el servicio elegido permita subida de archivos.

### Opción muy fácil: Google Forms

Puedes sustituir los formularios por botones que abran dos Google Forms diferentes.

## Enlaces incluidos

- Instagram: https://www.instagram.com/dubeditionvlc
- Canal: https://www.instagram.com/channel/AbYgdCJDxc26Cs2u/?igsh=MzJocHFnZHQ5ZnM3
- Hashtag: #seguimosenlonuestro


## KDDs y fotos

Se ha añadido la página `kdds.html` y una sección destacada en la home. Para poner fotos reales de las quedadas, crea/sustituye los archivos en la carpeta `assets` con estos nombres:

- `kdd-1.jpg`
- `kdd-2.jpg`
- `kdd-3.jpg`
- `kdd-4.jpg`
- `kdd-5.jpg`
- `kdd-6.jpg`

Después, en `kdds.html`, cambia `.svg` por `.jpg` en las seis imágenes. También puedes dejar los SVG provisionales hasta tener fotos finales.


## Novedades añadidas

- Integración del logo oficial de Dub Edition en cabecera y portada.
- Nueva sección en `unete.html` con marcas colaboradoras: **AL WORKS**, **LEGAUTO** y **294 DETAILING**.
- Los logos oficiales de Dub Edition están en `assets/dub-edition-logo-white.png` y `assets/dub-edition-logo-black.png`.


## Formularios Formspree configurados

- Solicitud para formar parte del club: `https://formspree.io/f/xqejnayw`
- Colaboraciones y empresas: `https://formspree.io/f/mpqnbwyz`

Los formularios ya están conectados en `unete.html`. Haz una prueba real desde la web publicada. En el primer envío, Formspree puede pedir confirmación o activación desde el panel.

Nota: el formulario del club incluye subida de fotos con `enctype="multipart/form-data"`. Si Formspree no adjunta fotos, revisa si tu plan permite file uploads.


## Fotos reales añadidas

Esta versión incluye fotos reales optimizadas dentro de `assets/photos/` y aplicadas en:

- Fondo principal de `index.html`, `kdds.html`, `rutas.html`, `eventos.html`, `comunidad.html` y `unete.html`.
- Galería de KDDs.
- Galería de rutas.
- Galería de DUB21 / eventos.
- Bloques visuales de comunidad.
- Feed visual decorativo de Instagram en la home.

Las imágenes se han renombrado y comprimido para que carguen mejor en GitHub Pages.


## URLs limpias

Esta versión usa carpetas con `index.html` para que GitHub Pages muestre URLs sin `.html`:

- `/`
- `/kdds/`
- `/rutas/`
- `/eventos/`
- `/comunidad/`
- `/unete/`

Importante: sube la estructura completa tal cual, manteniendo las carpetas `kdds`, `rutas`, `eventos`, `comunidad` y `unete`.


## Actualización colaboradores y móvil

- Se ha corregido la visualización móvil de la primera sección de `/unete/`.
- Se han añadido nuevos colaboradores: **LIDC** y **ZONABOX MEDIA** con enlaces a Instagram.

- Actualización: todos los colaboradores de la página Únete tienen enlace directo a Instagram: AL WORKS, LEGAUTO, 294 DETAILING, LIDC y ZONABOX MEDIA.
